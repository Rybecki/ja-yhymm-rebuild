/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, MouseEvent } from 'react';
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  Menu, 
  X, 
  ChevronRight, 
  ChevronDown,
  Star, 
  Calendar, 
  MapPin, 
  Mail, 
  User, 
  Bus, 
  Tent, 
  GraduationCap, 
  Shield, 
  Users, 
  PartyPopper,
  ArrowRight
} from 'lucide-react';

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'O nas', href: '#o-nas' },
    { name: 'Oferta', href: '#oferta' },
    { name: 'Tematyka', href: '#tematyka' },
    { name: 'Galeria', href: '#galeria' },
    { name: 'Aktualności', href: '#aktualnosci' },
    { name: 'Kontakt', href: '#kontakt' },
    { name: 'Dla Ciebie', href: '#dla-ciebie' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-dark/90 backdrop-blur-md py-4 shadow-xl' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <img 
            src="/utils/logo_ja-yhymm.png" 
            alt="Ja-yhymm Logo" 
            className="h-10 md:h-12 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-8 font-display">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-bold hover:text-primary transition-colors uppercase tracking-wider"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="tel:794997714" 
            className="flex items-center gap-2 bg-primary text-dark px-4 py-2 rounded-full font-bold text-sm transition-transform hover:scale-105"
          >
            <Phone size={16} />
            794 997 714
          </a>
        </div>

        {/* Mobile Toggle */}
        <button className="lg:hidden text-white" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-dark-lighter border-t border-white/10 p-6 lg:hidden"
          >
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-medium hover:text-primary transition-colors"
                >
                  {link.name}
                </a>
              ))}
              <a 
                href="tel:794997714" 
                className="flex items-center justify-center gap-2 bg-primary text-dark px-4 py-3 rounded-xl font-bold"
              >
                <Phone size={18} />
                794 997 714
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: MouseEvent) => {
    if (!heroRef.current) return;
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    const x = (clientX / innerWidth - 0.5) * 20;
    const y = (clientY / innerHeight - 0.5) * 20;
    setMousePos({ x, y });
  };

  return (
    <section 
      ref={heroRef}
      onMouseMove={handleMouseMove}
      className="relative h-screen w-full overflow-hidden flex items-center justify-center pt-20"
    >
      {/* Parallax Background */}
      <motion.div 
        animate={{ x: mousePos.x, y: mousePos.y }}
        transition={{ type: 'spring', damping: 30, stiffness: 100 }}
        className="absolute inset-0 z-0"
      >
        <div 
          className="absolute inset-0 bg-cover bg-center scale-110"
          style={{ 
            backgroundImage: 'url(/utils/quady-popr.png)',
            filter: 'brightness(0.4)'
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/20 via-transparent to-dark" />
      </motion.div>

      <div className="relative z-10 text-center px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-primary font-bold tracking-[0.3em] uppercase mb-4 text-sm md:text-base">
            Eventy inne niż wszystkie
          </h2>
          <h1 className="text-2xl md:text-4xl lg:text-5xl font-extrabold leading-tight mb-8 uppercase font-sophisticated tracking-tight text-white">
            EVENTY, IMPREZY FIRMOWE, <br className="hidden md:block" />
            OBOZY I KOLONIE, WYCIECZKI SZKOLNE, <br className="hidden md:block" />
            OBOZY dla klas mundurowych, <br className="hidden md:block" />
            WYJAZDY STUDENCKIE
          </h1>
          <p className="text-lg md:text-2xl text-white/80 mb-12 font-sophisticated font-light tracking-wide">
            Z przyjemnością to wszystko zorganizujemy <span className="text-primary font-bold">DLA CIEBIE!</span>
          </p>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-primary font-display"
          >
            Sprawdź naszą ofertę
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="o-nas" className="section-padding bg-dark-lighter relative overflow-hidden">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative group"
        >
          <div className="absolute -inset-4 bg-primary/20 rounded-2xl blur-2xl group-hover:bg-primary/30 transition-all" />
          <img 
            src="/utils/quady-i-motocross-galeria-ja-yhymm-1-1024x768.jpg" 
            alt="Quady i Motocross" 
            className="relative rounded-2xl shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
            referrerPolicy="no-referrer"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-primary font-bold uppercase tracking-widest mb-2">O nas</h2>
          <h3 className="text-3xl md:text-4xl font-extrabold mb-8 leading-tight font-display">Pasja, Ludzie, <br />Doświadczenie.</h3>
          <p className="text-lg text-white/70 leading-relaxed mb-10">
            Przy każdym z przedsięwzięć, których się podejmujemy pracuje sztab ludzi, gdzie każdy z nich jest fachowcem w swojej dziedzinie, a współpraca pomiędzy nimi przebiega w atmosferze pełnego zrozumienia i zaufania.
          </p>
          <button className="btn-primary">Poznaj nas bliżej</button>
        </motion.div>
      </div>
    </section>
  );
};

const Offer = () => {
  const offers = [
    { 
      title: 'Obozy i kolonie', 
      img: 'https://images.unsplash.com/photo-1523987355523-c7b5b0dd90a7?auto=format&fit=crop&q=80&w=2070',
      icon: <Tent className="text-primary" size={32} />
    },
    { 
      title: 'Wycieczki szkolne', 
      img: '/utils/wycieczki.jpg',
      icon: <GraduationCap className="text-primary" size={32} />
    },
    { 
      title: 'Obozy dla klas mundurowych', 
      img: '/utils/mili.jpg',
      icon: <Shield className="text-primary" size={32} />
    },
    { 
      title: 'Imprezy integracyjne, firmowe', 
      img: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=2069',
      icon: <Users className="text-primary" size={32} />
    },
    { 
      title: 'Wieczory kawalerskie i panieńskie', 
      img: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=2070',
      icon: <PartyPopper className="text-primary" size={32} />
    },
    { 
      title: 'Wyjazdy jedno i wielodniowe', 
      img: 'https://images.unsplash.com/photo-1523987355523-c7b5b0dd90a7?auto=format&fit=crop&q=80&w=2070',
      icon: <Bus className="text-primary" size={32} />
    },
  ];

  return (
    <section id="oferta" className="section-padding bg-dark">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-primary font-bold uppercase tracking-widest mb-4">Nasza Oferta</h2>
          <h3 className="text-3xl md:text-4xl font-extrabold uppercase font-display">Wybierz swoją przygodę</h3>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {offers.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-3xl bg-dark-lighter border border-white/5"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img 
                  src={item.img} 
                  alt={item.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/20 to-transparent opacity-90" />
              <div className="absolute bottom-0 left-0 w-full p-8">
                <div className="mb-4">{item.icon}</div>
                <h4 className="text-2xl font-bold mb-6 leading-tight">{item.title}</h4>
                <button className="flex items-center gap-2 text-primary font-bold uppercase text-xs tracking-widest group/btn">
                  Sprawdź szczegóły
                  <ArrowRight size={16} className="transition-transform group-hover/btn:translate-x-2" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="btn-primary">Sprawdź pełną ofertę</button>
        </div>
      </div>
    </section>
  );
};

const News = () => {
  const posts = [
    {
      title: 'Nowe terminy obozów letnich 2026!',
      excerpt: 'Zapisy na nadchodzący sezon właśnie wystartowały. Sprawdź co przygotowaliśmy w tym roku...',
      date: '12.03.2026',
      img: 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=2070'
    },
    {
      title: 'Relacja z zimowego poligonu klas mundurowych',
      excerpt: 'Mroźne poranki, ciężkie treningi i niesamowita satysfakcja. Zobacz jak poradzili sobie nasi kadeci...',
      date: '05.02.2026',
      img: '/utils/mili.jpg'
    },
    {
      title: 'Integracja firmowa w stylu survival',
      excerpt: 'Czy Twoi pracownicy potrafią przetrwać w dziczy? Nasz ostatni event pokazał, że team spirit to podstawa...',
      date: '20.01.2026',
      img: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=2069'
    }
  ];

  return (
    <section id="aktualnosci" className="section-padding bg-dark-lighter">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div>
            <h2 className="text-primary font-bold uppercase tracking-widest mb-4">Aktualności</h2>
            <h3 className="text-3xl md:text-4xl font-extrabold uppercase font-display">Co u nas słychać?</h3>
          </div>
          <button className="text-primary font-bold uppercase tracking-widest flex items-center gap-2 hover:gap-4 transition-all font-display">
            Wszystkie wpisy <ArrowRight size={20} />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <motion.article
              key={post.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-video overflow-hidden rounded-2xl mb-6">
                <img 
                  src={post.img} 
                  alt={post.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-primary text-xs font-bold uppercase tracking-widest mb-3 block">{post.date}</span>
              <h4 className="text-xl font-bold mb-4 group-hover:text-primary transition-colors">{post.title}</h4>
              <p className="text-white/60 text-sm leading-relaxed">{post.excerpt}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

const Reviews = () => {
  const reviews = [
    {
      name: 'Marek Wiśniewski',
      role: 'Dyrektor HR',
      text: 'Najlepsza integracja firmowa na jakiej byliśmy. Profesjonalizm w każdym calu, świetna kadra i emocje, których nie zapomnimy.',
      rating: 5
    },
    {
      name: 'Anna Kowalska',
      role: 'Rodzic',
      text: 'Mój syn wrócił z obozu mundurowego odmieniony. Większa dyscyplina, pewność siebie i masa nowych umiejętności. Polecam każdemu!',
      rating: 5
    },
    {
      name: 'Tomasz Nowak',
      role: 'Nauczyciel',
      text: 'Wycieczka szkolna zorganizowana perfekcyjnie. Dzieciaki zachwycone, a my jako opiekunowie mogliśmy spać spokojnie.',
      rating: 5
    }
  ];

  return (
    <section className="section-padding bg-dark">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-primary font-bold uppercase tracking-widest mb-4">Opinie</h2>
          <h3 className="text-3xl md:text-4xl font-extrabold uppercase font-display">Zaufali nam</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={review.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass-card p-10 rounded-3xl flex flex-col justify-between"
            >
              <div>
                <div className="flex gap-1 mb-6">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} size={16} className="fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-lg italic text-white/80 leading-relaxed mb-8">"{review.text}"</p>
              </div>
              <div>
                <p className="font-bold text-lg">{review.name}</p>
                <p className="text-primary text-sm uppercase tracking-widest">{review.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FormsSection = () => {
  const [activeTab, setActiveTab] = useState(0);

  const tabs = [
    'Obozy młodzieżowe',
    'Wycieczki i obozy szkolne',
    'Imprezy/Eventy/Szkolenia'
  ];

  const camps = [
    'Obóz Przetrwania "Dzicz"',
    'Akademia Młodego Kadeta',
    'Survival & Bushcraft',
    'Obóz Przygodowy "Explorer"',
    'Misja Specjalna: Poligon',
    'Wodne Szaleństwo: Mazury'
  ];

  const dates = [
    '01.07.2026 - 14.07.2026',
    '15.07.2026 - 28.07.2026',
    '01.08.2026 - 14.08.2026',
    '15.08.2026 - 28.08.2026'
  ];

  return (
    <section id="dla-ciebie" className="section-padding bg-dark-lighter">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-primary font-bold uppercase tracking-widest mb-4">Formularze zgłoszeniowe</h2>
          <h3 className="text-2xl md:text-3xl font-bold uppercase mb-8 font-display text-white">Zapisz się już teraz</h3>
          
          <div className="flex flex-wrap justify-center gap-4">
            {tabs.map((tab, index) => (
              <button
                key={tab}
                onClick={() => setActiveTab(index)}
                className={`px-6 py-3 rounded-xl font-bold transition-all ${activeTab === index ? 'bg-primary text-dark shadow-[0_0_15px_rgba(247,199,59,0.3)]' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-8 md:p-12 rounded-[2rem]"
        >
          <form className="space-y-12">
            {/* Sekcja: Osoba zgłaszająca */}
            <div>
              <h4 className="text-xl font-bold mb-6 flex items-center gap-3 text-primary">
                <User size={24} /> Osoba zgłaszająca
              </h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Imię i nazwisko</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Numer telefonu</label>
                  <input type="tel" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Adres email</label>
                  <input type="email" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Wybierz obóz</label>
                  <div className="relative">
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors appearance-none pr-10">
                      <option className="bg-dark">Wybierz z listy...</option>
                      {camps.map(c => <option key={c} className="bg-dark">{c}</option>)}
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-primary pointer-events-none" size={18} />
                  </div>
                </div>
              </div>
            </div>

            {/* Sekcja: Informacje o dziecku */}
            <div>
              <h4 className="text-xl font-bold mb-6 flex items-center gap-3 text-primary">
                <Users size={24} /> Informacje o dziecku
              </h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Imię i nazwisko dziecka</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Numer PESEL</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Data urodzenia</label>
                  <input type="date" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
              </div>
            </div>

            {/* Sekcja: Adres */}
            <div>
              <h4 className="text-xl font-bold mb-6 flex items-center gap-3 text-primary">
                <MapPin size={24} /> Adres zamieszkania/zameldowania
              </h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Miejscowość</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Kod pocztowy</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Ulica</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Numer domu/lokalu</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
              </div>
            </div>

            {/* Sekcja: Opcje wyjazdu */}
            <div>
              <h4 className="text-xl font-bold mb-6 flex items-center gap-3 text-primary">
                <Calendar size={24} /> Opcje wyjazdu
              </h4>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Turnus</label>
                  <div className="relative">
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors appearance-none pr-10">
                      {dates.map(d => <option key={d} className="bg-dark">{d}</option>)}
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-primary pointer-events-none" size={18} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Transport</label>
                  <div className="flex gap-4">
                    <label className="flex-1 flex items-center justify-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 cursor-pointer hover:bg-white/10 transition-colors">
                      <input type="radio" name="transport" className="accent-primary" /> Autobus
                    </label>
                    <label className="flex-1 flex items-center justify-center gap-2 bg-white/5 border border-white/10 rounded-xl p-3 cursor-pointer hover:bg-white/10 transition-colors">
                      <input type="radio" name="transport" className="accent-primary" /> Własny
                    </label>
                  </div>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Miejscowość wyjazdu</label>
                  <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-xs uppercase tracking-widest text-white/40">Dodatkowe uwagi</label>
                  <textarea rows={4} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary transition-colors resize-none" />
                </div>
              </div>
            </div>

            <button type="submit" className="w-full btn-primary py-4 text-lg">
              Wyślij zgłoszenie
            </button>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer id="kontakt" className="bg-dark pt-24 pb-12 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-4 gap-16 mb-20">
          <div className="lg:col-span-2">
            <img 
              src="/utils/logo_ja-yhymm.png" 
              alt="Ja-yhymm Logo" 
              className="h-12 w-auto object-contain mb-8"
              referrerPolicy="no-referrer"
            />
            <blockquote className="text-xl md:text-2xl font-serif italic text-white/60 leading-relaxed mb-6">
              „Znaczy, każdy swe obowiązki musi wykonywać porządnie. Ci, którzy nie wykonują ich jak mogą najlepiej — to znaczy, na ile ich stać fizycznie i duchowo — niszczą sami siebie.”
            </blockquote>
            <cite className="text-primary font-bold not-italic block mb-8">
              — Karol Olgierd Borchardt, "Znaczy Kapitan"
            </cite>
          </div>

          <div>
            <h5 className="text-sm font-bold uppercase tracking-[0.2em] mb-8 text-primary">Menu</h5>
            <ul className="space-y-4">
              {['O nas', 'Oferta', 'Tematyka', 'Galeria', 'Aktualności', 'Kontakt', 'Dla Ciebie'].map(item => (
                <li key={item}>
                  <a href={`#${item.toLowerCase().replace(' ', '-')}`} className="text-white/60 hover:text-primary transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-sm font-bold uppercase tracking-[0.2em] mb-8 text-primary">Kontakt</h5>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <MapPin className="text-primary shrink-0" size={20} />
                <span className="text-white/60">
                  Fundacja JA YHYMM… <br />
                  Integracja - Sport - Turystyka - Wypoczynek <br />
                  ul. Niwna 9, 40-406 Katowice
                </span>
              </li>
              <li className="flex gap-4">
                <Mail className="text-primary shrink-0" size={20} />
                <a href="mailto:biuro@ja-yhymm.pl" className="text-white/60 hover:text-primary transition-colors">biuro@ja-yhymm.pl</a>
              </li>
              <li className="flex gap-4">
                <Phone className="text-primary shrink-0" size={20} />
                <a href="tel:794997714" className="text-white/60 hover:text-primary transition-colors">+48 794-997-714</a>
              </li>
              <li className="text-white/40 text-sm">
                KRS 0000597760
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-white/30 text-xs uppercase tracking-widest">
          <p>Wszystkie prawa zastrzeżone © 2026 Ja-yhymm</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-primary transition-colors">Polityka prywatności</a>
            <a href="#" className="hover:text-primary transition-colors">Regulamin</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="bg-dark min-h-screen">
      <Navbar />
      <Hero />
      <About />
      <Offer />
      <News />
      <Reviews />
      <FormsSection />
      <Footer />
    </div>
  );
}
